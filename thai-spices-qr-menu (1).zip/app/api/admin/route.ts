import { NextResponse } from 'next/server'
import { db, ensureSchema, getAdminData } from '@/lib/turso'

function authorized(request: Request) {
  return request.headers.get('cookie')?.includes('thai-spices-admin=authenticated')
}

export async function GET(request: Request) {
  if (!authorized(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  return NextResponse.json(await getAdminData())
}

export async function PATCH(request: Request) {
  if (!authorized(request)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  await ensureSchema()
  const body = await request.json()
  const database = db()
  if (body.type === 'dish') {
    const d = body.data
    await database.execute({ sql: `INSERT INTO dishes (id, category, name, description, details, price, spice, dietary, allergens, badge, keywords, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET category=excluded.category, name=excluded.name, description=excluded.description, details=excluded.details, price=excluded.price, spice=excluded.spice, dietary=excluded.dietary, allergens=excluded.allergens, badge=excluded.badge, keywords=excluded.keywords, image_url=excluded.image_url, updated_at=CURRENT_TIMESTAMP`, args: [d.id, d.category, d.name, d.description, d.details, Number(d.price), Number(d.spice), JSON.stringify(d.dietary ?? []), JSON.stringify(d.allergens ?? []), d.badge || null, d.keywords ?? '', d.image_url || null] })
  } else if (body.type === 'delete-dish') {
    await database.execute({ sql: 'DELETE FROM dishes WHERE id = ?', args: [body.id] })
  } else if (body.type === 'category') {
    const c = body.data
    await database.execute({ sql: 'INSERT INTO categories (id, label, blurb) VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET label=excluded.label, blurb=excluded.blurb, updated_at=CURRENT_TIMESTAMP', args: [c.id, c.label, c.blurb] })
  } else if (body.type === 'delete-category') {
    if (body.id === 'popular') return NextResponse.json({ error: 'Cannot delete popular' }, { status: 400 })
    await database.execute({ sql: 'DELETE FROM categories WHERE id = ?', args: [body.id] })
  } else if (body.type === 'setting') {
    await database.execute({ sql: 'INSERT INTO restaurant_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP', args: [body.key, String(body.value)] })
  }
  return NextResponse.json({ ok: true })
}
