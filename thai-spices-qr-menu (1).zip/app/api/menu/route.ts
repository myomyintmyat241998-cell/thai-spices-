import { NextResponse } from 'next/server'
import { getAdminData } from '@/lib/turso'

export async function GET() {
  try {
    return NextResponse.json(await getAdminData(), { headers: { 'Cache-Control': 'no-store' } })
  } catch {
    return NextResponse.json({ error: 'Menu database is unavailable' }, { status: 503 })
  }
}
