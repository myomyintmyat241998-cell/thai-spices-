import { MenuApp } from '@/components/menu/menu-app'
import { getAdminData } from '@/lib/turso'

type SearchParams = Promise<Record<string, string | string[] | undefined>>

function firstValue(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value
}

// QR codes encode the table, e.g. /?table=12 — fall back to the demo table.
function normalizeTable(value: string | undefined) {
  const cleaned = (value ?? '')
    .replace(/[^0-9a-z]/gi, '')
    .slice(0, 4)
    .toUpperCase()
  if (!cleaned) return '08'
  return /^\d+$/.test(cleaned) ? cleaned.padStart(2, '0') : cleaned
}

export default async function Page({
  searchParams,
}: {
  searchParams: SearchParams
}) {
  const params = await searchParams
  const table = normalizeTable(firstValue(params.table))

  let initialData
  try {
    initialData = await getAdminData()
  } catch {
    initialData = undefined
  }

  return <MenuApp table={table} initialData={initialData} />
}
