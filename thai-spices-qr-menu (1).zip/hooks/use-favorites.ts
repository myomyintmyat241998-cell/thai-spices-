'use client'

import { useCallback } from 'react'
import useSWR from 'swr'

const FAVORITES_KEY = 'thai-spices/favorites'
const NO_FAVORITES: string[] = []

/** Session-scoped favorites shared across every screen through the SWR cache. */
export function useFavorites() {
  const { data, mutate } = useSWR<string[]>(FAVORITES_KEY, null, {
    fallbackData: NO_FAVORITES,
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
    revalidateIfStale: false,
  })
  const favorites = data ?? NO_FAVORITES

  const isFavorite = useCallback((dishId: string) => favorites.includes(dishId), [favorites])

  const toggleFavorite = useCallback(
    (dishId: string) => {
      void mutate(
        (current = NO_FAVORITES) =>
          current.includes(dishId)
            ? current.filter((id) => id !== dishId)
            : [dishId, ...current],
        { revalidate: false },
      )
    },
    [mutate],
  )

  return { favorites, isFavorite, toggleFavorite }
}
