'use client'

import { useCallback, useMemo } from 'react'
import useSWR from 'swr'
import { getDish } from '@/lib/menu-data'

export const MAX_QUANTITY = 20

type Selection = Record<string, number>

const SELECTION_KEY = 'thai-spices/selection'
const NO_SELECTION: Selection = {}

/** The guest's table list (dish → quantity) to show the server. No checkout involved. */
export function useSelection() {
  const { data, mutate } = useSWR<Selection>(SELECTION_KEY, null, {
    fallbackData: NO_SELECTION,
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
    revalidateIfStale: false,
  })
  const selection = data ?? NO_SELECTION

  const setQuantity = useCallback(
    (dishId: string, quantity: number) => {
      const clamped = Math.max(0, Math.min(MAX_QUANTITY, Math.round(quantity)))
      void mutate(
        (current = NO_SELECTION) => {
          const next = { ...current }
          if (clamped === 0) delete next[dishId]
          else next[dishId] = clamped
          return next
        },
        { revalidate: false },
      )
    },
    [mutate],
  )

  const clear = useCallback(() => {
    void mutate(NO_SELECTION, { revalidate: false })
  }, [mutate])

  const items = useMemo(
    () =>
      Object.entries(selection).flatMap(([dishId, quantity]) => {
        const dish = getDish(dishId)
        return dish ? [{ dish, quantity }] : []
      }),
    [selection],
  )

  const count = items.reduce((sum, item) => sum + item.quantity, 0)
  const total = items.reduce((sum, item) => sum + item.quantity * item.dish.price, 0)

  return { selection, items, count, total, setQuantity, clear }
}
