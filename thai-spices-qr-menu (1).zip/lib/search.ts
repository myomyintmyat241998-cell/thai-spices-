import { pluralize } from './format'
import {
  categories,
  DIETARY_INFO,
  type DietaryTag,
  type Dish,
  type SpiceLevel,
} from './menu-data'

export interface DishFilters {
  dietary: DietaryTag[]
  spice: SpiceLevel[]
}

export const NO_FILTERS: DishFilters = { dietary: [], spice: [] }

export const SEARCH_SUGGESTIONS = ['Pad Thai', 'Curry', 'Tom Yum', 'Prawn', 'Mango']

export function describeResults(count: number, query: string) {
  if (!query) return `${pluralize(count, 'dish matches', 'dishes match')} your filters`
  if (count === 0) return `No results for “${query}”`
  return `${pluralize(count, 'result')} for “${query}”`
}

export function normalizeText(value: string) {
  return value
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
}

const searchTextCache = new Map<string, string>()

function getSearchText(dish: Dish) {
  const cached = searchTextCache.get(dish.id)
  if (cached) return cached

  const category = categories.find((item) => item.id === dish.category)
  const dietaryTags: DietaryTag[] = dish.dietary.includes('vegan')
    ? [...dish.dietary, 'vegetarian']
    : dish.dietary
  const dietaryWords = dietaryTags.map((tag) => DIETARY_INFO[tag].label)
  const spiceWords = dish.spice >= 2 ? ['spicy', 'hot'] : ['mild']

  const text = normalizeText(
    [
      dish.name,
      dish.description,
      dish.keywords,
      category?.label,
      ...dietaryWords,
      ...spiceWords,
    ].join(' '),
  )
  searchTextCache.set(dish.id, text)
  return text
}

export function matchesDietary(dish: Dish, tag: DietaryTag) {
  if (tag === 'vegetarian') {
    return dish.dietary.includes('vegetarian') || dish.dietary.includes('vegan')
  }
  return dish.dietary.includes(tag)
}

/** Every query word must match; dietary filters are combined, spice levels are alternatives. */
export function filterDishes(list: Dish[], query: string, filters: DishFilters = NO_FILTERS) {
  const tokens = normalizeText(query).split(/\s+/).filter(Boolean)

  return list.filter((dish) => {
    if (filters.dietary.some((tag) => !matchesDietary(dish, tag))) return false
    if (filters.spice.length > 0 && !filters.spice.includes(dish.spice)) return false
    if (tokens.length === 0) return true
    const text = getSearchText(dish)
    return tokens.every((token) => text.includes(token))
  })
}
