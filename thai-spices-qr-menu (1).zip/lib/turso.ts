import { createClient } from '@libsql/client'
import { categories, dishes } from './menu-data'
import { restaurant } from './restaurant'

const client = createClient({
  url: process.env.TURSO_DATABASE_URL ?? 'file:local.db',
  authToken: process.env.TURSO_AUTH_TOKEN,
})

let schemaPromise: Promise<void> | null = null

export function db() {
  return client
}

export function ensureSchema() {
  if (!schemaPromise) {
    schemaPromise = (async () => {
      await client.batch([
        `CREATE TABLE IF NOT EXISTS dishes (id TEXT PRIMARY KEY, category TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL, details TEXT NOT NULL, price INTEGER NOT NULL, spice INTEGER NOT NULL, dietary TEXT NOT NULL, allergens TEXT NOT NULL, badge TEXT, keywords TEXT NOT NULL, image_url TEXT, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
        `CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY, label TEXT NOT NULL, blurb TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
        `CREATE TABLE IF NOT EXISTS restaurant_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
      ], 'write')
      try { await client.execute('ALTER TABLE dishes ADD COLUMN image_url TEXT') } catch {}
      const count = await client.execute('SELECT COUNT(*) AS count FROM dishes')
      if (Number(count.rows[0]?.count ?? 0) === 0) {
        await client.batch(dishes.map((dish) => ({
          sql: 'INSERT INTO dishes (id, category, name, description, details, price, spice, dietary, allergens, badge, keywords) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          args: [dish.id, dish.category, dish.name, dish.description, dish.details, dish.price, dish.spice, JSON.stringify(dish.dietary), JSON.stringify(dish.allergens), dish.badge ?? null, dish.keywords],
        })), 'write')
      }
      const categoryCount = await client.execute('SELECT COUNT(*) AS count FROM categories')
      if (Number(categoryCount.rows[0]?.count ?? 0) === 0) {
        await client.batch(categories.map((category) => ({
          sql: 'INSERT INTO categories (id, label, blurb) VALUES (?, ?, ?)',
          args: [category.id, category.label, category.blurb],
        })), 'write')
      }
      const settingCount = await client.execute('SELECT COUNT(*) AS count FROM restaurant_settings')
      if (Number(settingCount.rows[0]?.count ?? 0) === 0) {
        await client.batch(Object.entries(restaurant).filter(([, value]) => typeof value === 'string').map(([key, value]) => ({
          sql: 'INSERT INTO restaurant_settings (key, value) VALUES (?, ?)',
          args: [key, value as string],
        })), 'write')
      }
    })()
  }
  return schemaPromise
}

export async function getAdminData() {
  await ensureSchema()
  const [dishRows, categoryRows, settingsRows] = await Promise.all([
    client.execute('SELECT * FROM dishes ORDER BY category, name'),
    client.execute('SELECT * FROM categories ORDER BY CASE id WHEN \'popular\' THEN 0 ELSE 1 END, label'),
    client.execute('SELECT key, value FROM restaurant_settings ORDER BY key'),
  ])
  const plainDishes = dishRows.rows.map((row) => ({
    id: String(row.id),
    category: String(row.category),
    name: String(row.name),
    description: String(row.description),
    details: String(row.details),
    price: Number(row.price),
    spice: Number(row.spice),
    dietary: parseJsonArray(row.dietary),
    allergens: parseJsonArray(row.allergens),
    ...(row.badge ? { badge: String(row.badge) } : {}),
    keywords: String(row.keywords),
    ...(row.image_url ? { image_url: String(row.image_url) } : {}),
  }))
  const plainCategories = categoryRows.rows.map((row) => ({
    id: String(row.id),
    label: String(row.label),
    blurb: String(row.blurb),
  }))

  // LibSQL returns Row objects with a custom prototype. Clone the final payload so
  // Next.js can safely pass it from this server function into the client app.
  return JSON.parse(JSON.stringify({
    dishes: plainDishes,
    categories: plainCategories,
    settings: Object.fromEntries(settingsRows.rows.map((row) => [String(row.key), String(row.value)])),
  })) as {
    dishes: typeof plainDishes
    categories: typeof plainCategories
    settings: Record<string, string>
  }
}

function parseJsonArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String)
  try {
    const parsed = JSON.parse(String(value ?? '[]'))
    return Array.isArray(parsed) ? parsed.map(String) : []
  } catch {
    return []
  }
}
