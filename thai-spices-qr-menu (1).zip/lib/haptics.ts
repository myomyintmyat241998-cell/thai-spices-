/** Light tap feedback on devices that support it (Android); a no-op elsewhere. */
export function haptic(duration = 8) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    navigator.vibrate(duration)
  }
}
