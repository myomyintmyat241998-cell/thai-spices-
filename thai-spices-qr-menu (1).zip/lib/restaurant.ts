export const restaurant = {
  name: 'Thai Spices',
  tagline: 'Thai cuisine in the heart of Sukhumvit',
  diningRoomAlt: 'The Thai Spices dining room with carved teak panels and warm brass lamps',
  hours: 'Daily, 11:30 – 22:30',
  lastOrder: 'Last kitchen order at 22:00',
  address: '88 Sukhumvit Soi 31, Watthana, Bangkok 10110',
  phoneDisplay: '+66 2 258 8899',
  phoneHref: 'tel:+6622588899',
  mapsUrl:
    'https://www.google.com/maps/search/?api=1&query=88+Sukhumvit+Soi+31+Watthana+Bangkok',
  wifi: {
    network: 'ThaiSpices_Guest',
    password: 'sawasdee2026',
  },
  pricesNote:
    'Prices are in Thai Baht (THB).',
  allergyNote:
    'Please tell your server about any allergies. Our kitchen handles peanuts, shellfish, soy and gluten, so traces may be present.',
}
