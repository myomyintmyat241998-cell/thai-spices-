export type DishCategoryId =
  | 'starters'
  | 'curries'
  | 'noodles'
  | 'rice'
  | 'desserts'
  | 'drinks'
export type CategoryId = 'popular' | DishCategoryId
export type SpiceLevel = 0 | 1 | 2 | 3
export type DietaryTag = 'vegetarian' | 'vegan' | 'gluten-free'
export type Allergen =
  | 'peanuts'
  | 'tree-nuts'
  | 'shellfish'
  | 'fish'
  | 'egg'
  | 'dairy'
  | 'soy'
  | 'gluten'
export type DishBadge = 'popular' | 'chef'

export interface Category {
  id: CategoryId
  label: string
  blurb: string
}

export interface Dish {
  id: string
  category: DishCategoryId
  name: string
  description: string
  details: string
  price: number
  spice: SpiceLevel
  dietary: DietaryTag[]
  allergens: Allergen[]
  badge?: DishBadge
  keywords: string
  image_url?: string
}

export const SPICE_LEVELS: SpiceLevel[] = [0, 1, 2, 3]

export const SPICE_LABELS: Record<SpiceLevel, string> = {
  0: 'Not spicy',
  1: 'Mild',
  2: 'Medium',
  3: 'Hot',
}

export const SPICE_HINTS: Record<SpiceLevel, string> = {
  0: 'No chili at all',
  1: 'A gentle warmth',
  2: 'Noticeable, balanced heat',
  3: 'Authentically Thai hot',
}

export const DIETARY_TAGS: DietaryTag[] = ['vegetarian', 'vegan', 'gluten-free']

export const DIETARY_INFO: Record<DietaryTag, { label: string; short: string; hint: string }> = {
  vegetarian: { label: 'Vegetarian', short: 'V', hint: 'No meat or seafood' },
  vegan: { label: 'Vegan', short: 'VG', hint: 'No animal products' },
  'gluten-free': {
    label: 'Gluten-free',
    short: 'GF',
    hint: 'Made without gluten-containing ingredients',
  },
}

export const ALLERGEN_LABELS: Record<Allergen, string> = {
  peanuts: 'Peanuts',
  'tree-nuts': 'Tree nuts',
  shellfish: 'Shellfish',
  fish: 'Fish',
  egg: 'Egg',
  dairy: 'Dairy',
  soy: 'Soy',
  gluten: 'Gluten',
}

export const BADGE_LABELS: Record<DishBadge, string> = {
  popular: 'Popular',
  chef: "Chef's pick",
}

export const categories: Category[] = [
  { id: 'popular', label: 'Popular', blurb: "Guest favourites and our chef's signatures" },
  { id: 'starters', label: 'Starters', blurb: 'Soups, salads and small plates to share' },
  { id: 'curries', label: 'Curries', blurb: 'Curry pastes pounded fresh every morning' },
  { id: 'noodles', label: 'Noodles', blurb: 'Wok-tossed to order over a roaring flame' },
  { id: 'rice', label: 'Rice', blurb: 'Made with fragrant hom mali rice from Surin' },
  { id: 'desserts', label: 'Desserts', blurb: 'A sweet, cooling finish' },
  { id: 'drinks', label: 'Drinks', blurb: 'House-made and refreshing' },
]

export const categoryCovers: Record<DishCategoryId, string> = {
  starters: 'spring-rolls',
  curries: 'green-curry',
  noodles: 'pad-thai',
  rice: 'pineapple-fried-rice',
  desserts: 'mango-sticky-rice',
  drinks: 'thai-iced-tea',
}

export const dishes: Dish[] = [
  {
    id: 'tom-yum-goong',
    category: 'starters',
    name: 'Tom Yum Goong',
    description: 'Hot and sour river prawn soup with lemongrass, galangal and lime leaf.',
    details:
      'Our signature soup. Whole river prawns simmered in a fragrant broth of lemongrass, galangal, kaffir lime leaf and bird’s eye chili, finished with fresh lime and roasted chili paste. Served creamy unless you ask for the clear version.',
    price: 320,
    spice: 3,
    dietary: ['gluten-free'],
    allergens: ['shellfish', 'fish'],
    badge: 'popular',
    keywords: 'soup prawn prawns shrimp seafood lemongrass sour',
  },
  {
    id: 'spring-rolls',
    category: 'starters',
    name: 'Crispy Spring Rolls',
    description: 'Glass noodle and vegetable rolls with sweet chili plum sauce.',
    details:
      'Hand-rolled every morning with glass noodles, cabbage, carrot, wood ear mushroom and Thai basil, then fried until shatteringly crisp. Served with our house sweet chili and plum dipping sauce.',
    price: 180,
    spice: 0,
    dietary: ['vegan'],
    allergens: ['gluten', 'soy'],
    keywords: 'spring roll rolls fried crispy vegetable appetizer snack',
  },
  {
    id: 'chicken-satay',
    category: 'starters',
    name: 'Chicken Satay',
    description: 'Turmeric-grilled chicken skewers with peanut sauce and cucumber relish.',
    details:
      'Free-range chicken thigh marinated overnight in turmeric, coriander seed and coconut milk, then grilled over charcoal. Served with a rich roasted peanut sauce and a sweet-sour cucumber and shallot relish.',
    price: 220,
    spice: 0,
    dietary: ['gluten-free'],
    allergens: ['peanuts'],
    keywords: 'chicken skewer skewers grill grilled peanut satay bbq',
  },
  {
    id: 'som-tum',
    category: 'starters',
    name: 'Som Tum',
    description: 'Pounded green papaya, long beans, tomato, dried shrimp and peanuts.',
    details:
      'Shredded green papaya pounded to order in a clay mortar with garlic, fresh chili, long beans and cherry tomatoes, dressed with lime, palm sugar and fish sauce, then finished with dried shrimp and roasted peanuts. Tell us how much heat you like.',
    price: 190,
    spice: 2,
    dietary: ['gluten-free'],
    allergens: ['peanuts', 'shellfish', 'fish'],
    keywords: 'salad papaya peanut shrimp green papaya salad',
  },
  {
    id: 'green-curry',
    category: 'curries',
    name: 'Green Curry',
    description: 'Fresh green chili curry with chicken, Thai eggplant and sweet basil.',
    details:
      'Made daily from a hand-pounded paste of green chilies, lemongrass, galangal and coriander root, simmered with free-range chicken, Thai eggplant and coconut cream, then finished with sweet basil. Best with jasmine rice.',
    price: 320,
    spice: 2,
    dietary: ['gluten-free'],
    allergens: ['fish', 'shellfish'],
    badge: 'popular',
    keywords: 'curry chicken green coconut basil eggplant',
  },
  {
    id: 'massaman-curry',
    category: 'curries',
    name: 'Massaman Curry',
    description: 'Slow-braised beef cheek, baby potatoes and roasted peanuts.',
    details:
      'A royal court classic with Persian roots. Beef cheek braised for six hours with cardamom, cinnamon, star anise and tamarind, with baby potatoes, shallots and roasted peanuts. Rich, gently sweet and mildly spiced.',
    price: 420,
    spice: 1,
    dietary: ['gluten-free'],
    allergens: ['peanuts', 'fish'],
    badge: 'chef',
    keywords: 'curry beef potato peanut coconut',
  },
  {
    id: 'red-curry-duck',
    category: 'curries',
    name: 'Red Curry with Roast Duck',
    description: 'Roast duck, lychee, pineapple and cherry tomato in red curry.',
    details:
      'Crisp-skinned roast duck in a velvety red curry with sweet lychee, pineapple, cherry tomatoes and Thai basil. A balance of heat, sweetness and gentle smoke that pairs beautifully with jasmine rice.',
    price: 460,
    spice: 2,
    dietary: ['gluten-free'],
    allergens: ['fish', 'shellfish'],
    badge: 'chef',
    keywords: 'curry duck red lychee pineapple coconut',
  },
  {
    id: 'yellow-curry-tofu',
    category: 'curries',
    name: 'Yellow Curry with Tofu',
    description: 'Golden tofu, potato and carrot in a mild turmeric coconut curry.',
    details:
      'Our plant-based curry, made with a vegan paste of turmeric, cumin and coriander seed, simmered in coconut milk with golden fried tofu, potato, carrot and onion. Gentle, warming and fragrant.',
    price: 290,
    spice: 1,
    dietary: ['vegan'],
    allergens: ['soy'],
    keywords: 'curry tofu yellow potato coconut plant based',
  },
  {
    id: 'pad-thai',
    category: 'noodles',
    name: 'Pad Thai',
    description: 'Rice noodles, grilled river prawn, tamarind, egg, tofu and peanuts.',
    details:
      'Our most-ordered dish. Thin rice noodles tossed in a hot wok with house tamarind sauce, palm sugar, egg, pressed tofu, chives and bean sprouts, crowned with a grilled river prawn. Add lime, crushed peanuts and chili flakes to taste.',
    price: 380,
    spice: 0,
    dietary: ['gluten-free'],
    allergens: ['shellfish', 'peanuts', 'egg', 'fish', 'soy'],
    badge: 'popular',
    keywords: 'noodles noodle prawn prawns shrimp tamarind peanut egg tofu',
  },
  {
    id: 'drunken-noodles',
    category: 'noodles',
    name: 'Drunken Noodles',
    description: 'Wide rice noodles, prawn and squid with holy basil and fresh chili.',
    details:
      'A fiery late-night favourite. Wide rice noodles wok-charred with prawns, squid, holy basil, green peppercorns, baby corn, garlic and plenty of fresh bird’s eye chili.',
    price: 340,
    spice: 3,
    dietary: [],
    allergens: ['shellfish', 'soy', 'gluten', 'fish'],
    keywords: 'noodles noodle seafood prawn shrimp squid basil drunken kee mao',
  },
  {
    id: 'khao-soi',
    category: 'noodles',
    name: 'Khao Soi',
    description: 'Northern curry noodle soup with braised chicken and crispy noodles.',
    details:
      'A Chiang Mai classic. Egg noodles in a rich coconut curry broth with a slow-braised chicken leg, topped with crispy fried noodles. Served with pickled mustard greens, shallots and lime to brighten every bite.',
    price: 320,
    spice: 2,
    dietary: [],
    allergens: ['gluten', 'egg', 'fish'],
    badge: 'chef',
    keywords: 'noodles noodle soup curry chicken northern chiang mai coconut',
  },
  {
    id: 'pineapple-fried-rice',
    category: 'rice',
    name: 'Pineapple Fried Rice',
    description: 'Prawns, cashews and curry-scented jasmine rice served in a pineapple.',
    details:
      'Jasmine rice wok-fried with prawns, sweet pineapple, roasted cashews, raisins, egg and a touch of yellow curry powder, served in a hollowed half pineapple. Mild, fragrant and great for sharing.',
    price: 320,
    spice: 0,
    dietary: [],
    allergens: ['shellfish', 'tree-nuts', 'egg', 'soy'],
    keywords: 'rice fried prawn shrimp pineapple cashew',
  },
  {
    id: 'kra-pao',
    category: 'rice',
    name: 'Holy Basil Pork',
    description: 'Minced pork, holy basil and chili over rice with a crispy fried egg.',
    details:
      'Thailand’s favourite comfort food. Hand-chopped pork stir-fried with holy basil, garlic and bird’s eye chili, served over jasmine rice with a crispy-edged fried egg. Break the yolk and mix it all together.',
    price: 240,
    spice: 3,
    dietary: [],
    allergens: ['egg', 'soy', 'fish', 'gluten'],
    badge: 'popular',
    keywords: 'rice pork basil holy egg minced kra pao gaprao',
  },
  {
    id: 'crab-fried-rice',
    category: 'rice',
    name: 'Crab Fried Rice',
    description: 'Jasmine rice wok-fried with blue crab meat, egg and spring onion.',
    details:
      'Generous lumps of fresh blue swimmer crab tossed through egg-fried jasmine rice with spring onion and a splash of light soy. Served with cucumber, lime and chili fish sauce on the side.',
    price: 360,
    spice: 0,
    dietary: [],
    allergens: ['shellfish', 'egg', 'soy', 'gluten'],
    keywords: 'rice fried crab seafood egg',
  },
  {
    id: 'mango-sticky-rice',
    category: 'desserts',
    name: 'Mango Sticky Rice',
    description: 'Ripe mango, pandan sticky rice and salted coconut cream.',
    details:
      'Sweet nam dok mai mango with warm sticky rice steamed with pandan and coconut milk, finished with salted coconut cream and crispy mung beans. Served while the season’s best mangoes last.',
    price: 220,
    spice: 0,
    dietary: ['vegan', 'gluten-free'],
    allergens: [],
    badge: 'popular',
    keywords: 'dessert sweet mango sticky rice coconut',
  },
  {
    id: 'tub-tim-grob',
    category: 'desserts',
    name: 'Tub Tim Grob',
    description: 'Crunchy water chestnut rubies in sweet coconut milk over ice.',
    details:
      'Water chestnut cubes coated in tapioca and tinted ruby red, served chilled in fragrant coconut milk with young jackfruit and crushed ice. Light, crunchy and refreshing after a spicy meal.',
    price: 160,
    spice: 0,
    dietary: ['vegan', 'gluten-free'],
    allergens: [],
    keywords: 'dessert sweet coconut water chestnut ice rubies',
  },
  {
    id: 'coconut-ice-cream',
    category: 'desserts',
    name: 'Coconut Ice Cream',
    description: 'Coconut ice cream in the shell with peanuts and sweet corn.',
    details:
      'House-churned coconut ice cream served in a young coconut shell with tender coconut flesh, roasted peanuts, sweet corn and a drizzle of palm sugar syrup. Dairy-free and wonderfully creamy.',
    price: 180,
    spice: 0,
    dietary: ['vegan', 'gluten-free'],
    allergens: ['peanuts'],
    keywords: 'dessert sweet ice cream coconut peanut dairy free',
  },
  {
    id: 'thai-iced-tea',
    category: 'drinks',
    name: 'Thai Iced Tea',
    description: 'Strong-brewed Thai tea with star anise and sweetened condensed milk.',
    details:
      'Ceylon tea brewed strong with star anise and vanilla bean, sweetened with condensed milk and poured over ice with a float of fresh milk. Ask for it less sweet, or dairy-free with coconut milk.',
    price: 120,
    spice: 0,
    dietary: ['vegetarian', 'gluten-free'],
    allergens: ['dairy'],
    badge: 'popular',
    keywords: 'drink drinks tea milk iced cold',
  },
  {
    id: 'lemongrass-cooler',
    category: 'drinks',
    name: 'Lemongrass Pandan Cooler',
    description: 'Lemongrass, pandan and lime over ice, lightly sweetened.',
    details:
      'Fresh lemongrass and pandan leaves steeped and chilled, brightened with lime and a little palm sugar. Clean, floral and the perfect cooling partner for curries.',
    price: 130,
    spice: 0,
    dietary: ['vegan', 'gluten-free'],
    allergens: [],
    keywords: 'drink drinks lemongrass pandan lime cold mocktail',
  },
  {
    id: 'young-coconut',
    category: 'drinks',
    name: 'Young Coconut',
    description: 'Chilled aromatic coconut from Ratchaburi, opened fresh.',
    details:
      'Aromatic coconuts from Ratchaburi province, served ice-cold with a spoon for the tender flesh. Naturally sweet and hydrating.',
    price: 140,
    spice: 0,
    dietary: ['vegan', 'gluten-free'],
    allergens: [],
    keywords: 'drink drinks coconut water fresh cold',
  },
]

const dishesById = new Map(dishes.map((dish) => [dish.id, dish]))

export type MenuSnapshot = {
  dishes: Array<Record<string, unknown>>
  categories: Array<Record<string, unknown>>
  settings?: Record<string, string>
}

export function hydrateMenuData(snapshot: MenuSnapshot) {
  if (snapshot.dishes?.length) {
    dishes.splice(0, dishes.length, ...snapshot.dishes.map((row) => ({
      ...row,
      price: Number(row.price),
      spice: Number(row.spice) as SpiceLevel,
      dietary: typeof row.dietary === 'string' ? JSON.parse(row.dietary) : row.dietary ?? [],
      allergens: typeof row.allergens === 'string' ? JSON.parse(row.allergens) : row.allergens ?? [],
      badge: row.badge || undefined,
      image_url: row.image_url ? String(row.image_url) : undefined,
    })) as Dish[])
    dishesById.clear()
    dishes.forEach((dish) => dishesById.set(dish.id, dish))
  }
  if (snapshot.categories?.length) {
    categories.splice(0, categories.length, ...snapshot.categories.map((row) => ({
      id: row.id,
      label: row.label,
      blurb: row.blurb,
    })) as Category[])
  }
}

export function getDish(id: string) {
  return dishesById.get(id)
}

export function getDishesByCategory(id: CategoryId) {
  if (id === 'popular') return dishes.filter((dish) => dish.badge)
  return dishes.filter((dish) => dish.category === id)
}

export function dishImage(dish: Pick<Dish, 'id' | 'image_url'>, size: 'full' | 'thumb' = 'full') {
  return dish.image_url || `/images/dishes/${dish.id}${size === 'thumb' ? '-sm' : ''}.webp`
}

/** Vegan dishes are also vegetarian, so only the stronger tag is shown. */
export function displayDietaryTags(tags: DietaryTag[]) {
  return tags.includes('vegan') ? tags.filter((tag) => tag !== 'vegetarian') : tags
}
