'use client'

import type { Dish } from '@/lib/menu-data'
import { cn } from '@/lib/utils'
import { DishCard } from './dish-card'

export function DishList({
  dishes,
  showBadge = true,
  className,
}: {
  dishes: Dish[]
  showBadge?: boolean
  className?: string
}) {
  return (
    <ul className={cn('grid gap-3 md:grid-cols-2', className)}>
      {dishes.map((dish, index) => (
        <li
          key={dish.id}
          className="animate-in fade-in-0 slide-in-from-bottom-3 fill-mode-both duration-500 ease-out"
          style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }}
        >
          <DishCard dish={dish} showBadge={showBadge} />
        </li>
      ))}
    </ul>
  )
}
