'use client'

import { useAppState } from './app-state'
import { TableSheet } from './table-sheet'

export function AppHeader() {
  const { navigate } = useAppState()

  return (
    <header
      data-app-header
      className="sticky top-0 z-40 border-b border-border bg-background/85 pt-[env(safe-area-inset-top)] backdrop-blur-xl"
    >
      <div className="flex h-14 items-center justify-between gap-3 px-5">
        <button
          type="button"
          onClick={() => navigate('menu')}
          className="-mx-1 rounded-md px-1 font-serif text-2xl leading-none text-foreground transition-opacity active:opacity-70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Thai <span className="text-primary italic">Spices</span>
        </button>
        <TableSheet />
      </div>
    </header>
  )
}
