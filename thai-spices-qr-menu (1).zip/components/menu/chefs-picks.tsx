'use client'

import { useId, useMemo } from 'react'
import Image from 'next/image'
import { formatPrice, pluralize } from '@/lib/format'
import { dishes, dishImage, type Dish } from '@/lib/menu-data'
import { useAppState } from './app-state'
import { DietaryTags, SpiceIndicator } from './dish-meta'
import { FavoriteButton } from './favorite-button'
import { SectionHeading } from './section-heading'

export function ChefsPicks() {
  const titleId = useId()
  const picks = useMemo(() => dishes.filter((dish) => dish.badge === 'chef'), [])

  return (
    <section aria-labelledby={titleId}>
      <SectionHeading
        id={titleId}
        title="Chef's picks"
        meta={pluralize(picks.length, 'dish', 'dishes')}
      />
      <ul className="no-scrollbar -mx-5 mt-4 flex snap-x snap-mandatory scroll-px-5 gap-3 overflow-x-auto px-5 md:mx-0 md:grid md:grid-cols-3 md:overflow-visible md:px-0">
        {picks.map((dish, index) => (
          <li key={dish.id} className="w-64 shrink-0 snap-start md:w-auto">
            <FeaturedDishCard dish={dish} preload={index === 0} />
          </li>
        ))}
      </ul>
    </section>
  )
}

/** Square, image-led tile — every pick is the same size regardless of name length. */
function FeaturedDishCard({ dish, preload }: { dish: Dish; preload: boolean }) {
  const { openDish } = useAppState()

  return (
    <article className="group relative flex aspect-square w-full flex-col justify-end overflow-hidden rounded-3xl border border-border bg-secondary transition-transform duration-200 ease-out has-[[data-card-trigger]:active]:scale-[0.98] has-[[data-card-trigger]:focus-visible]:ring-2 has-[[data-card-trigger]:focus-visible]:ring-ring">
      <Image
        src={dishImage(dish)}
        alt=""
        fill
        preload={preload}
        sizes="(min-width: 768px) 15rem, 16rem"
        className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
      />
      <div
        aria-hidden
        className="absolute inset-0 bg-linear-to-t from-background via-background/40 via-45% to-transparent"
      />
      {/* z-index lifts this flex item above the photo without positioning it, so the
          trigger's pseudo-element still stretches over the whole tile. */}
      <div className="z-1 flex flex-col gap-2 p-4">
        <h3 className="font-serif text-[1.625rem] leading-[1.1] text-balance text-foreground">
          <button
            type="button"
            data-card-trigger
            onClick={() => openDish(dish.id)}
            className="text-left after:absolute after:inset-0 after:rounded-3xl after:content-[''] focus-visible:outline-none"
          >
            {dish.name}
          </button>
        </h3>
        <div className="flex items-center gap-2.5">
          <span className="text-[0.9375rem] font-semibold text-foreground tabular-nums">
            {formatPrice(dish.price)}
          </span>
          <SpiceIndicator level={dish.spice} />
          <DietaryTags tags={dish.dietary} />
        </div>
      </div>
      <FavoriteButton
        dishId={dish.id}
        name={dish.name}
        variant="overlay"
        className="absolute top-3 right-3"
      />
    </article>
  )
}
