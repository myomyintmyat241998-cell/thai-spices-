'use client'

import { useEffect, useId, useMemo, useRef } from 'react'
import {
  Tabs,
  TabsContent,
  TabsIndicator,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import { pluralize } from '@/lib/format'
import {
  categories,
  dishes,
  getDishesByCategory,
  type Category,
  type CategoryId,
} from '@/lib/menu-data'
import { useAppState } from './app-state'
import { ChefsPicks } from './chefs-picks'
import { DishList } from './dish-list'
import { SectionHeading } from './section-heading'

export function CategoryBrowser() {
  const { category, setCategory } = useAppState()
  const rootRef = useRef<HTMLDivElement>(null)
  const listRef = useRef<HTMLDivElement>(null)

  // Keep the active tab centred in the horizontal scroller.
  useEffect(() => {
    const list = listRef.current
    const tab = list?.querySelector<HTMLElement>(`[data-category="${category}"]`)
    if (!list || !tab) return
    const left = tab.offsetLeft - (list.clientWidth - tab.offsetWidth) / 2
    list.scrollTo({ left: Math.max(0, left), behavior: 'smooth' })
  }, [category])

  const handleChange = (value: CategoryId) => {
    setCategory(value)
    const root = rootRef.current
    if (!root) return
    // If the guest has scrolled into the list, jump back so the new category starts under the bar.
    const headerHeight =
      document.querySelector<HTMLElement>('[data-app-header]')?.offsetHeight ?? 0
    const top = root.getBoundingClientRect().top + window.scrollY - headerHeight
    if (window.scrollY > top + 1) window.scrollTo({ top, behavior: 'instant' })
  }

  return (
    <Tabs
      ref={rootRef}
      value={category}
      onValueChange={(value) => handleChange(value as CategoryId)}
      className="gap-0"
    >
      <div className="sticky top-(--header-height) z-30 border-b border-border bg-background/85 backdrop-blur-xl">
        <TabsList
          ref={listRef}
          aria-label="Menu categories"
          className="no-scrollbar scroll-fade-x relative h-auto w-full justify-start gap-1 overflow-x-auto rounded-none bg-transparent px-5 py-2.5 group-data-horizontal/tabs:h-auto"
        >
          {categories.map((item) => (
            <TabsTrigger
              key={item.id}
              value={item.id}
              data-category={item.id}
              className="relative z-10 h-10 flex-none rounded-full px-4 text-sm font-medium text-muted-foreground transition-[color,transform] duration-300 hover:text-foreground active:scale-95 data-active:bg-transparent data-active:text-primary-foreground group-data-[variant=default]/tabs-list:data-active:shadow-none"
            >
              {item.label}
            </TabsTrigger>
          ))}
          <TabsIndicator
            renderBeforeHydration
            className="absolute top-(--active-tab-top) left-(--active-tab-left) z-0 h-(--active-tab-height) w-(--active-tab-width) rounded-full bg-primary transition-[left,width] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
          />
        </TabsList>
      </div>
      {categories.map((item) => (
        <TabsContent
          key={item.id}
          value={item.id}
          className="animate-in fade-in-0 slide-in-from-bottom-2 px-5 pt-6 duration-300 ease-out"
        >
          {item.id === 'popular' ? <PopularPanel /> : <CategoryPanel category={item} />}
        </TabsContent>
      ))}
    </Tabs>
  )
}

function PopularPanel() {
  const titleId = useId()
  const mostOrdered = useMemo(() => dishes.filter((dish) => dish.badge === 'popular'), [])

  return (
    <div className="flex flex-col gap-9">
      <ChefsPicks />
      <section aria-labelledby={titleId}>
        <SectionHeading
          id={titleId}
          title="Most ordered"
          meta={pluralize(mostOrdered.length, 'dish', 'dishes')}
        />
        <DishList dishes={mostOrdered} showBadge={false} className="mt-4" />
      </section>
    </div>
  )
}

function CategoryPanel({ category }: { category: Category }) {
  const titleId = useId()
  const items = useMemo(() => getDishesByCategory(category.id), [category.id])

  return (
    <section aria-labelledby={titleId}>
      <SectionHeading
        id={titleId}
        title={category.label}
        meta={pluralize(items.length, 'dish', 'dishes')}
        description={category.blurb}
      />
      <DishList dishes={items} className="mt-4" />
    </section>
  )
}
