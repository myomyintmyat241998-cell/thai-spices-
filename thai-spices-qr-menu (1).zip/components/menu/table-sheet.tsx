'use client'

import Image from 'next/image'
import { UtensilsCrossed } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer'
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty'
import { useSelection } from '@/hooks/use-selection'
import { formatPrice, pluralize } from '@/lib/format'
import { dishImage } from '@/lib/menu-data'
import { restaurant } from '@/lib/restaurant'
import { cn } from '@/lib/utils'
import { useAppState } from './app-state'
import { QuantityStepper } from './quantity-stepper'

/** The header's Table button and the sheet listing everything added for this table. */
export function TableSheet() {
  const { table, navigate, isTableSheetOpen: open, setTableSheetOpen: setOpen } = useAppState()
  const { items, count, total, setQuantity, clear } = useSelection()
  const itemsLabel = pluralize(count, 'item')

  return (
    <>
      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerTrigger
          render={
            <button
              type="button"
              aria-label={`Table ${table}, ${count === 0 ? 'nothing added yet' : `${itemsLabel} added`}`}
              className="flex h-10 items-center gap-2 rounded-full border border-border bg-card pr-1.5 pl-3.5 text-sm transition-[transform,background-color] duration-150 hover:bg-secondary active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          }
        >
          <span className="text-muted-foreground">Table</span>
          <span className="font-semibold text-foreground tabular-nums">{table}</span>
          <span
            key={count}
            aria-hidden
            className={cn(
              'grid h-7 min-w-7 place-items-center rounded-full px-1.5 text-xs font-semibold tabular-nums',
              count > 0
                ? 'animate-bump bg-primary text-primary-foreground'
                : 'bg-secondary text-primary',
            )}
          >
            {count > 0 ? count : <UtensilsCrossed className="size-3.5" />}
          </span>
        </DrawerTrigger>

        <DrawerContent className="mx-auto w-full max-w-lg data-[swipe-direction=down]:rounded-t-[1.75rem]">
          <div aria-hidden className="mx-auto mt-2.5 h-1 w-10 shrink-0 rounded-full bg-foreground/20" />
          <DrawerHeader className="gap-1.5 px-5 pt-4 pb-5 text-left group-data-[swipe-axis=y]/drawer-popup:text-left">
            <div className="flex items-baseline justify-between gap-3">
              <DrawerTitle className="font-serif text-[2rem] leading-none font-normal">
                Table {table}
              </DrawerTitle>
              {count > 0 ? (
                <span className="shrink-0 text-sm text-muted-foreground tabular-nums">{itemsLabel}</span>
              ) : null}
            </div>
            <DrawerDescription className="text-pretty">
              Your picks for this visit. Show this list to your server when you&apos;re ready to order.
            </DrawerDescription>
          </DrawerHeader>

          {count === 0 ? (
            <Empty className="flex-none border-t border-border px-6 pt-8 pb-[calc(2rem+env(safe-area-inset-bottom))]">
              <EmptyHeader>
                <EmptyMedia
                  variant="icon"
                  className="size-14 rounded-full bg-primary/12 text-primary [&_svg:not([class*='size-'])]:size-6"
                >
                  <UtensilsCrossed />
                </EmptyMedia>
                <EmptyTitle className="font-serif text-2xl font-normal tracking-normal text-foreground">
                  Nothing added yet
                </EmptyTitle>
                <EmptyDescription>
                  Open any dish and tap &ldquo;Add to table&rdquo; &mdash; your picks will gather here.
                </EmptyDescription>
              </EmptyHeader>
              <EmptyContent>
                <DrawerClose
                  onClick={() => navigate('menu')}
                  render={<Button className="h-11 rounded-full px-5 font-semibold" />}
                >
                  Browse the menu
                </DrawerClose>
              </EmptyContent>
            </Empty>
          ) : (
            <>
              <ul className="no-scrollbar min-h-0 flex-1 divide-y divide-border overflow-y-auto overscroll-contain border-t border-border px-5">
                {items.map(({ dish, quantity }) => (
                  <li key={dish.id} className="flex items-center gap-3 py-3">
                    <span className="relative size-14 shrink-0 overflow-hidden rounded-xl bg-secondary">
                      <Image
                        src={dishImage(dish, 'thumb')}
                        alt=""
                        fill
                        sizes="3.5rem"
                        className="object-cover"
                      />
                    </span>
                    <span className="flex min-w-0 flex-1 flex-col">
                      <span className="truncate text-[0.9375rem] leading-6 font-medium text-foreground">
                        {dish.name}
                      </span>
                      <span className="text-sm text-muted-foreground tabular-nums">
                        {formatPrice(dish.price * quantity)}
                      </span>
                    </span>
                    <QuantityStepper
                      size="sm"
                      min={0}
                      value={quantity}
                      onChange={(next) => setQuantity(dish.id, next)}
                      label={dish.name}
                    />
                  </li>
                ))}
              </ul>

              <DrawerFooter className="gap-3 border-t border-border px-5 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
                <div className="flex items-baseline justify-between gap-4">
                  <span className="text-sm text-muted-foreground">Estimated total</span>
                  <span className="text-2xl leading-none font-semibold text-foreground tabular-nums">
                    {formatPrice(total)}
                  </span>
                </div>
                <p className="text-xs leading-relaxed text-muted-foreground">{restaurant.pricesNote}</p>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={clear} className="h-12 flex-1 rounded-full">
                    Clear all
                  </Button>
                  <DrawerClose
                    render={
                      <Button className="h-12 flex-[2] rounded-full text-[0.9375rem] font-semibold" />
                    }
                  >
                    Done
                  </DrawerClose>
                </div>
              </DrawerFooter>
            </>
          )}
        </DrawerContent>
      </Drawer>
      <span role="status" className="sr-only">
        {count > 0 ? `${itemsLabel} on Table ${table}` : ''}
      </span>
    </>
  )
}
