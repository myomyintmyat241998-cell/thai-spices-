'use client'

import { useMemo } from 'react'
import { dishes } from '@/lib/menu-data'
import { describeResults, filterDishes } from '@/lib/search'
import { useAppState } from './app-state'
import { CategoryBrowser } from './category-browser'
import { DishList } from './dish-list'
import { NoResults } from './no-results'
import { SearchField } from './search-field'

export function MenuScreen() {
  const { query } = useAppState()
  const isSearching = query.trim().length > 0

  return (
    <div className="animate-in fade-in-0 slide-in-from-bottom-2 duration-300 ease-out">
      <section aria-labelledby="menu-greeting" className="px-5 pt-6 pb-4">
        <h1
          id="menu-greeting"
          className="font-serif text-[2rem] leading-[1.1] text-balance text-foreground"
        >
          What are you craving?
        </h1>
        <SearchField id="menu-search" className="mt-4" />
      </section>
      {isSearching ? <MenuSearchResults /> : <CategoryBrowser />}
    </div>
  )
}

function MenuSearchResults() {
  const { query, setQuery } = useAppState()
  const trimmedQuery = query.trim()
  const results = useMemo(() => filterDishes(dishes, trimmedQuery), [trimmedQuery])

  return (
    <section aria-label="Search results" className="px-5 pt-2">
      <p role="status" className="text-sm text-muted-foreground">
        {describeResults(results.length, trimmedQuery)}
      </p>
      {results.length > 0 ? (
        <DishList dishes={results} className="mt-3" />
      ) : (
        <NoResults query={trimmedQuery} onClear={() => setQuery('')} className="mt-3" />
      )}
    </section>
  )
}
