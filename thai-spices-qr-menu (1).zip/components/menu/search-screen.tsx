'use client'

import { useId, useMemo, useState, type ReactNode } from 'react'
import Image from 'next/image'
import { Flame } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { pluralize } from '@/lib/format'
import {
  categories,
  categoryCovers,
  DIETARY_INFO,
  DIETARY_TAGS,
  dishes,
  dishImage,
  getDish,
  getDishesByCategory,
  SPICE_LABELS,
  SPICE_LEVELS,
  type Category,
  type DietaryTag,
  type DishCategoryId,
  type SpiceLevel,
} from '@/lib/menu-data'
import { describeResults, filterDishes, SEARCH_SUGGESTIONS } from '@/lib/search'
import { useAppState } from './app-state'
import { DIETARY_ICONS } from './dish-meta'
import { DishList } from './dish-list'
import { NoResults } from './no-results'
import { SearchField } from './search-field'
import { SectionHeading } from './section-heading'

const chipClassName =
  'h-10 gap-1.5 rounded-full border border-border bg-card px-4 text-sm font-medium text-muted-foreground transition-[color,background-color,border-color,transform] duration-200 hover:bg-secondary hover:text-foreground active:scale-95 aria-pressed:border-primary/60 aria-pressed:bg-primary/15 aria-pressed:text-primary'

const browseCategories = categories.filter(
  (category): category is Category & { id: DishCategoryId } => category.id !== 'popular',
)

export function SearchScreen() {
  const { query, setQuery } = useAppState()
  const [dietary, setDietary] = useState<DietaryTag[]>([])
  const [spice, setSpice] = useState<SpiceLevel[]>([])

  const trimmedQuery = query.trim()
  const hasFilters = dietary.length > 0 || spice.length > 0
  const isSearching = trimmedQuery.length > 0 || hasFilters

  const results = useMemo(
    () => (isSearching ? filterDishes(dishes, trimmedQuery, { dietary, spice }) : []),
    [isSearching, trimmedQuery, dietary, spice],
  )

  const clearAll = () => {
    setQuery('')
    setDietary([])
    setSpice([])
  }

  return (
    <div className="animate-in fade-in-0 slide-in-from-bottom-2 px-5 pt-6 duration-300 ease-out">
      <h1 className="font-serif text-[2rem] leading-[1.1] text-foreground">Search</h1>
      <p className="mt-1 text-sm text-muted-foreground">Find dishes by name, ingredient or flavour</p>
      <SearchField id="search-screen-input" className="mt-4" />

      <div className="mt-5 flex flex-col gap-4">
        <FilterGroup label="Dietary">
          {(labelId) => (
            <ToggleGroup
              multiple
              value={dietary}
              onValueChange={(value) => setDietary(value as DietaryTag[])}
              spacing={2}
              aria-labelledby={labelId}
              className="no-scrollbar scroll-fade-x -mx-5 w-[calc(100%+2.5rem)] overflow-x-auto px-5"
            >
              {DIETARY_TAGS.map((tag) => {
                const Icon = DIETARY_ICONS[tag]
                return (
                  <ToggleGroupItem key={tag} value={tag} className={chipClassName}>
                    <Icon data-icon="inline-start" aria-hidden />
                    {DIETARY_INFO[tag].label}
                  </ToggleGroupItem>
                )
              })}
            </ToggleGroup>
          )}
        </FilterGroup>
        <FilterGroup label="Spice level">
          {(labelId) => (
            <ToggleGroup
              multiple
              value={spice.map(String)}
              onValueChange={(value) => setSpice(value.map(Number) as SpiceLevel[])}
              spacing={2}
              aria-labelledby={labelId}
              className="no-scrollbar scroll-fade-x -mx-5 w-[calc(100%+2.5rem)] overflow-x-auto px-5"
            >
              {SPICE_LEVELS.map((level) => (
                <ToggleGroupItem key={level} value={String(level)} className={chipClassName}>
                  {level > 0 ? (
                    <span aria-hidden className="flex text-chili">
                      {Array.from({ length: level }, (_, index) => (
                        <Flame key={index} className="size-3.5 fill-current" />
                      ))}
                    </span>
                  ) : null}
                  {SPICE_LABELS[level]}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          )}
        </FilterGroup>
      </div>

      {isSearching ? (
        <section aria-label="Search results" className="mt-7">
          <div className="flex items-center justify-between gap-3">
            <p role="status" className="text-sm text-muted-foreground">
              {describeResults(results.length, trimmedQuery)}
            </p>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearAll}
              className="h-9 shrink-0 rounded-full px-3 text-primary hover:text-primary"
            >
              Clear all
            </Button>
          </div>
          {results.length > 0 ? (
            <DishList dishes={results} className="mt-3" />
          ) : (
            <NoResults query={trimmedQuery} onClear={clearAll} className="mt-3" />
          )}
        </section>
      ) : (
        <>
          <section className="mt-9">
            <SectionHeading title="Popular searches" />
            <div className="mt-3 flex flex-wrap gap-2">
              {SEARCH_SUGGESTIONS.map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  onClick={() => setQuery(suggestion)}
                  className="h-10 rounded-full bg-card px-4 text-sm"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </section>
          <section className="mt-9">
            <SectionHeading title="Browse by category" />
            <ul className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3">
              {browseCategories.map((category) => (
                <li key={category.id}>
                  <CategoryTile category={category} />
                </li>
              ))}
            </ul>
          </section>
        </>
      )}
    </div>
  )
}

function FilterGroup({
  label,
  children,
}: {
  label: string
  children: (labelId: string) => ReactNode
}) {
  const labelId = useId()
  return (
    <div className="flex flex-col gap-2">
      <span id={labelId} className="text-xs font-medium text-muted-foreground">
        {label}
      </span>
      {children(labelId)}
    </div>
  )
}

function CategoryTile({ category }: { category: Category & { id: DishCategoryId } }) {
  const { setCategory, setQuery, navigate } = useAppState()
  const cover = getDish(categoryCovers[category.id])
  const count = getDishesByCategory(category.id).length

  const handleClick = () => {
    setQuery('')
    setCategory(category.id)
    navigate('menu', { resetScroll: true })
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      className="group relative flex aspect-[4/3] w-full items-end overflow-hidden rounded-2xl border border-border bg-secondary p-3.5 text-left transition-transform duration-200 ease-out active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {cover ? (
        <Image
          src={dishImage(cover)}
          alt=""
          fill
          sizes="(min-width: 768px) 15rem, 50vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
      ) : null}
      <span
        aria-hidden
        className="absolute inset-0 bg-linear-to-t from-background/95 via-background/40 to-background/0"
      />
      <span className="relative flex flex-col">
        <span className="font-serif text-[1.375rem] leading-tight text-foreground">
          {category.label}
        </span>
        <span className="text-xs text-muted-foreground">{pluralize(count, 'dish', 'dishes')}</span>
      </span>
    </button>
  )
}
