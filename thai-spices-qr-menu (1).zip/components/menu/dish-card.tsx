'use client'

import Image from 'next/image'
import { formatPrice } from '@/lib/format'
import { BADGE_LABELS, dishImage, type Dish } from '@/lib/menu-data'
import { useAppState } from './app-state'
import { DietaryTags, SpiceIndicator } from './dish-meta'
import { FavoriteButton } from './favorite-button'
import { useSelection } from '@/hooks/use-selection'

/** Fixed-height row: one-line name, two-line description, meta pinned to the bottom. */
export function DishCard({ dish, showBadge = true }: { dish: Dish; showBadge?: boolean }) {
  const { openDish } = useAppState()
  const { selection, setQuantity } = useSelection()

  const addToTable = () => {
    setQuantity(dish.id, (selection[dish.id] ?? 0) + 1)
  }

  return (
    <article className="group relative flex gap-3.5 rounded-2xl border border-border bg-card p-2.5 transition-[transform,border-color,background-color] duration-200 ease-out hover:border-primary/25 has-[[data-card-trigger]:active]:scale-[0.98] has-[[data-card-trigger]:active]:bg-secondary has-[[data-card-trigger]:focus-visible]:ring-2 has-[[data-card-trigger]:focus-visible]:ring-ring">
      <div className="relative size-26 shrink-0 overflow-hidden rounded-lg bg-secondary">
        <Image
          src={dishImage(dish, 'thumb')}
          alt=""
          fill
          sizes="6.5rem"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {showBadge && dish.badge ? (
          <span className="absolute top-1.5 left-1.5 rounded-full bg-background/80 px-2 py-0.5 text-[0.6875rem] leading-4 font-semibold text-primary backdrop-blur-sm">
            {BADGE_LABELS[dish.badge]}
          </span>
        ) : null}
      </div>
      <div className="flex min-w-0 flex-1 flex-col py-1">
        <h3 className="text-base leading-6 font-semibold text-foreground">
          {/* The pseudo-element stretches this button over the whole card. */}
          <button
            type="button"
            data-card-trigger
            onClick={() => openDish(dish.id)}
            className="block w-full truncate text-left after:absolute after:inset-0 after:rounded-2xl after:content-[''] focus-visible:outline-none"
          >
            {dish.name}
          </button>
        </h3>
        <p className="mt-0.5 line-clamp-2 text-sm leading-5 text-muted-foreground">
          {dish.description}
        </p>
        <div className="mt-auto flex items-center gap-2.5">
          <span className="text-[0.9375rem] font-semibold text-foreground tabular-nums">
            {formatPrice(dish.price)}
          </span>
          <SpiceIndicator level={dish.spice} />
          <DietaryTags tags={dish.dietary} />
          <div className="relative z-10 ml-auto flex items-center gap-1">
            <FavoriteButton dishId={dish.id} name={dish.name} className="-my-2" />
            <button
              type="button"
              aria-label={`Add ${dish.name} to table`}
              onClick={addToTable}
              className="inline-flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm transition-transform duration-150 hover:brightness-110 active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card"
            >
              <span aria-hidden="true" className="text-lg leading-none font-medium">+</span>
            </button>
          </div>
        </div>
      </div>
    </article>
  )
}
