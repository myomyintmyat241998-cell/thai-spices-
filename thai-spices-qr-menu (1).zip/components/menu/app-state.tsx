'use client'

import {
  createContext,
  useCallback,
  useContext,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import { hydrateMenuData, type CategoryId, type MenuSnapshot } from '@/lib/menu-data'

export type AppTab = 'menu' | 'search' | 'favorites' | 'info'

interface AppStateContextValue {
  table: string
  activeTab: AppTab
  navigate: (tab: AppTab, options?: { resetScroll?: boolean }) => void
  category: CategoryId
  setCategory: (category: CategoryId) => void
  query: string
  setQuery: (query: string) => void
  activeDishId: string | null
  isDishOpen: boolean
  openDish: (dishId: string) => void
  setDishOpen: (open: boolean) => void
  isTableSheetOpen: boolean
  setTableSheetOpen: (open: boolean) => void
}

const AppStateContext = createContext<AppStateContextValue | null>(null)

export function AppProviders({ table, children, initialData }: { table: string; children: ReactNode; initialData?: MenuSnapshot }) {
  if (initialData) hydrateMenuData(initialData)

  const [activeTab, setActiveTab] = useState<AppTab>('menu')
  const [category, setCategory] = useState<CategoryId>('popular')
  const [query, setQuery] = useState('')
  const [activeDishId, setActiveDishId] = useState<string | null>(null)
  const [isDishOpen, setDishOpen] = useState(false)
  const [isTableSheetOpen, setTableSheetOpen] = useState(false)

  const activeTabRef = useRef<AppTab>('menu')
  const scrollPositions = useRef<Partial<Record<AppTab, number>>>({})

  // Each tab keeps its own scroll position, like a native tab bar.
  const navigate = useCallback((tab: AppTab, options?: { resetScroll?: boolean }) => {
    const current = activeTabRef.current
    if (current === tab) {
      window.scrollTo({ top: 0, behavior: 'smooth' })
      return
    }
    scrollPositions.current[current] = window.scrollY
    if (options?.resetScroll) scrollPositions.current[tab] = 0
    activeTabRef.current = tab
    setActiveTab(tab)
  }, [])

  useLayoutEffect(() => {
    window.scrollTo(0, scrollPositions.current[activeTab] ?? 0)
  }, [activeTab])

  const openDish = useCallback((dishId: string) => {
    setActiveDishId(dishId)
    setDishOpen(true)
  }, [])

  const value = useMemo(
    () => ({
      table,
      activeTab,
      navigate,
      category,
      setCategory,
      query,
      setQuery,
      activeDishId,
      isDishOpen,
      openDish,
      setDishOpen,
      isTableSheetOpen,
      setTableSheetOpen,
    }),
    [table, activeTab, navigate, category, query, activeDishId, isDishOpen, openDish, isTableSheetOpen],
  )

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>
}

export function useAppState() {
  const context = useContext(AppStateContext)
  if (!context) throw new Error('useAppState must be used within AppProviders.')
  return context
}
