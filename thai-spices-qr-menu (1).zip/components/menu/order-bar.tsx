'use client'

import { ChevronRight, ClipboardList } from 'lucide-react'
import { useSelection } from '@/hooks/use-selection'
import { formatPrice, pluralize } from '@/lib/format'
import { Button } from '@/components/ui/button'
import { useAppState } from './app-state'

export function OrderBar() {
  const { count, total } = useSelection()
  const { table, setTableSheetOpen } = useAppState()

  if (!count) return null

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-(--nav-height) z-35 px-4 pb-3 md:bottom-4">
      <div className="pointer-events-auto mx-auto flex max-w-md items-center gap-3 rounded-2xl border border-primary/25 bg-card/95 p-2 pl-3 shadow-[0_12px_40px_rgba(0,0,0,0.35)] backdrop-blur-xl md:max-w-xl">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
          <ClipboardList aria-hidden className="size-4" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-semibold text-foreground">Your order</span>
          <span className="block text-xs text-muted-foreground">{pluralize(count, 'item')} · {formatPrice(total)}</span>
        </span>
        <Button onClick={() => setTableSheetOpen(true)} className="h-10 shrink-0 rounded-xl px-3.5 font-semibold">
          View order
          <ChevronRight data-icon="inline-end" aria-hidden />
        </Button>
      </div>
    </div>
  )
}
