'use client'

import { useRef, type KeyboardEvent } from 'react'
import { Search, X } from 'lucide-react'
import {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupInput,
} from '@/components/ui/input-group'
import { cn } from '@/lib/utils'
import { useAppState } from './app-state'

export function SearchField({ id, className }: { id: string; className?: string }) {
  const { query, setQuery } = useAppState()
  const inputRef = useRef<HTMLInputElement>(null)

  // Enter dismisses the mobile keyboard so results are fully visible.
  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key !== 'Enter' || event.nativeEvent.isComposing || event.keyCode === 229) return
    event.currentTarget.blur()
  }

  return (
    <div role="search" className={className}>
      <InputGroup
        className={cn(
          'h-12 rounded-full border-border bg-card pr-1 transition-colors',
          'has-[[data-slot=input-group-control]:focus-visible]:bg-secondary',
        )}
      >
        <InputGroupAddon className="pl-4">
          <Search aria-hidden className="size-[1.125rem] text-primary" />
        </InputGroupAddon>
        <InputGroupInput
          ref={inputRef}
          id={id}
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Search Thai dishes"
          aria-label="Search the menu"
          enterKeyHint="search"
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
          className="h-full text-base md:text-base"
        />
        {query ? (
          <InputGroupAddon align="inline-end">
            <InputGroupButton
              size="icon-sm"
              aria-label="Clear search"
              onClick={() => {
                setQuery('')
                inputRef.current?.focus()
              }}
              className="size-9 rounded-full text-muted-foreground hover:text-foreground"
            >
              <X aria-hidden />
            </InputGroupButton>
          </InputGroupAddon>
        ) : null}
      </InputGroup>
    </div>
  )
}
