'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerTitle,
} from '@/components/ui/drawer'
import { MAX_QUANTITY, useSelection } from '@/hooks/use-selection'
import { formatPrice } from '@/lib/format'
import { haptic } from '@/lib/haptics'
import { ALLERGEN_LABELS, dishImage, getDish, SPICE_LABELS, type Dish } from '@/lib/menu-data'
import { useAppState } from './app-state'
import { DietaryChips, DishBadgeLabel, SpiceMeter } from './dish-meta'
import { FavoriteButton } from './favorite-button'
import { QuantityStepper } from './quantity-stepper'

export function DishSheet() {
  const { activeDishId, isDishOpen, setDishOpen } = useAppState()
  const dish = activeDishId ? getDish(activeDishId) : undefined

  return (
    <Drawer open={isDishOpen} onOpenChange={setDishOpen}>
      <DrawerContent className="mx-auto w-full max-w-lg data-[swipe-axis=y]:[--drawer-content-max-height:calc(100dvh-2.5rem)] data-[swipe-direction=down]:rounded-t-[1.75rem]">
        {dish ? <DishDetails key={dish.id} dish={dish} onDone={() => setDishOpen(false)} /> : null}
      </DrawerContent>
    </Drawer>
  )
}

function DishDetails({ dish, onDone }: { dish: Dish; onDone: () => void }) {
  const { table } = useAppState()
  const { selection, setQuantity } = useSelection()
  const inList = selection[dish.id] ?? 0
  const [quantity, setLocalQuantity] = useState(inList > 0 ? inList : 1)

  const lineTotal = formatPrice(dish.price * quantity)
  const ctaLabel =
    quantity === 0
      ? 'Remove from table'
      : inList > 0
        ? `Update · ${lineTotal}`
        : `Add to table · ${lineTotal}`

  const handleConfirm = () => {
    setQuantity(dish.id, quantity)
    haptic(12)
    onDone()
  }

  return (
    <>
      <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto overscroll-contain">
        <div className="relative aspect-[4/3] w-full bg-secondary sm:aspect-[16/10]">
          <Image
            src={dishImage(dish)}
            alt=""
            fill
            sizes="(min-width: 32rem) 32rem, 100vw"
            className="object-cover"
          />
          <div aria-hidden className="absolute inset-x-0 top-0 h-24 bg-linear-to-b from-background/70 to-transparent" />
          <div aria-hidden className="absolute inset-x-0 bottom-0 h-28 bg-linear-to-t from-popover to-transparent" />
          <div aria-hidden className="absolute top-2.5 left-1/2 h-1 w-10 -translate-x-1/2 rounded-full bg-foreground/50" />
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <FavoriteButton dishId={dish.id} name={dish.name} variant="overlay" />
            <DrawerClose
              render={
                <button
                  type="button"
                  aria-label="Close"
                  className="grid size-10 place-items-center rounded-full bg-background/65 text-foreground backdrop-blur-md transition-[transform,background-color] duration-150 hover:bg-background/80 active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                />
              }
            >
              <X aria-hidden className="size-5" />
            </DrawerClose>
          </div>
        </div>

        <div className="relative -mt-8 px-5 pb-6">
          {dish.badge ? <DishBadgeLabel badge={dish.badge} /> : null}
          <div className="mt-3 flex items-start justify-between gap-4">
            <DrawerTitle className="min-w-0 font-serif text-[2rem] leading-[1.1] font-normal text-balance">
              {dish.name}
            </DrawerTitle>
            <p className="shrink-0 pt-1 text-xl font-semibold text-foreground tabular-nums">
              {formatPrice(dish.price)}
            </p>
          </div>
          <DrawerDescription className="mt-3 text-[0.9375rem] leading-relaxed text-pretty text-muted-foreground">
            {dish.details}
          </DrawerDescription>

          <dl className="mt-6 overflow-hidden rounded-2xl border border-border bg-card">
            <div className="flex flex-col gap-2 p-4">
              <dt className="text-xs font-medium text-muted-foreground">Spice level</dt>
              <dd className="flex flex-col gap-1">
                <span className="flex items-center gap-2.5">
                  <SpiceMeter level={dish.spice} />
                  <span className="text-sm font-medium text-foreground">{SPICE_LABELS[dish.spice]}</span>
                </span>
                <span className="text-xs text-muted-foreground">
                  Ask your server to make it milder or hotter.
                </span>
              </dd>
            </div>
            <div className="flex flex-col gap-2 border-t border-border p-4">
              <dt className="text-xs font-medium text-muted-foreground">Dietary</dt>
              <dd>
                <DietaryChips tags={dish.dietary} />
              </dd>
            </div>
            <div className="flex flex-col gap-2 border-t border-border p-4">
              <dt className="text-xs font-medium text-muted-foreground">Allergens</dt>
              <dd className="text-sm text-foreground">
                {dish.allergens.length > 0
                  ? dish.allergens.map((allergen) => ALLERGEN_LABELS[allergen]).join(' · ')
                  : 'No major allergens'}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="shrink-0 border-t border-border bg-popover px-5 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
        {inList > 0 ? (
          <p className="mb-2 text-center text-xs text-muted-foreground">
            {inList} already on Table {table}
          </p>
        ) : null}
        <div className="flex items-center gap-3">
          <QuantityStepper
            value={quantity}
            min={inList > 0 ? 0 : 1}
            max={MAX_QUANTITY}
            onChange={setLocalQuantity}
            label={dish.name}
          />
          <Button
            size="lg"
            variant={quantity === 0 ? 'outline' : 'default'}
            onClick={handleConfirm}
            className="h-12 min-w-0 flex-1 rounded-full px-4 text-[0.9375rem] font-semibold"
          >
            <span className="truncate">{ctaLabel}</span>
          </Button>
        </div>
      </div>
    </>
  )
}
