'use client'

import { useMemo } from 'react'
import { BookOpen, Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty'
import { useFavorites } from '@/hooks/use-favorites'
import { pluralize } from '@/lib/format'
import { getDish, type Dish } from '@/lib/menu-data'
import { useAppState } from './app-state'
import { DishList } from './dish-list'

export function FavoritesScreen() {
  const { navigate } = useAppState()
  const { favorites } = useFavorites()
  const favoriteDishes = useMemo(
    () => favorites.map(getDish).filter((dish): dish is Dish => Boolean(dish)),
    [favorites],
  )

  return (
    <div className="animate-in fade-in-0 slide-in-from-bottom-2 px-5 pt-6 duration-300 ease-out">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="font-serif text-[2rem] leading-[1.1] text-foreground">Favorites</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your shortlist for this visit</p>
        </div>
        {favoriteDishes.length > 0 ? (
          <span className="pb-0.5 text-xs font-medium text-muted-foreground tabular-nums">
            {pluralize(favoriteDishes.length, 'dish', 'dishes')}
          </span>
        ) : null}
      </div>

      {favoriteDishes.length > 0 ? (
        <DishList dishes={favoriteDishes} className="mt-5" />
      ) : (
        <Empty className="mt-6 animate-in fade-in-0 zoom-in-95 rounded-3xl border border-dashed border-border bg-card/40 px-6 py-12 duration-300">
          <EmptyHeader>
            <EmptyMedia
              variant="icon"
              className="size-14 rounded-full bg-primary/12 text-primary [&_svg:not([class*='size-'])]:size-6"
            >
              <Heart />
            </EmptyMedia>
            <EmptyTitle className="font-serif text-2xl font-normal tracking-normal text-foreground">
              No favorites yet
            </EmptyTitle>
            <EmptyDescription>Tap the heart on any dish to keep it here while you decide.</EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button onClick={() => navigate('menu')} className="h-11 rounded-full px-5 font-semibold">
              <BookOpen data-icon="inline-start" aria-hidden />
              Browse the menu
            </Button>
          </EmptyContent>
        </Empty>
      )}
    </div>
  )
}
