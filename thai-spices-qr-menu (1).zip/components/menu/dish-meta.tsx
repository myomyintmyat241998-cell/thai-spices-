'use client'

import { ChefHat, Flame, Leaf, Star, Vegan, WheatOff, type LucideIcon } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import {
  BADGE_LABELS,
  DIETARY_INFO,
  displayDietaryTags,
  SPICE_LABELS,
  type DietaryTag,
  type DishBadge,
  type SpiceLevel,
} from '@/lib/menu-data'
import { cn } from '@/lib/utils'

export const DIETARY_ICONS: Record<DietaryTag, LucideIcon> = {
  vegetarian: Leaf,
  vegan: Vegan,
  'gluten-free': WheatOff,
}

/** Compact flames for cards. Non-spicy dishes stay visually quiet. */
export function SpiceIndicator({ level, className }: { level: SpiceLevel; className?: string }) {
  const label = `Spice level: ${SPICE_LABELS[level]}`

  if (level === 0) return <span className="sr-only">{label}</span>

  return (
    <span title={SPICE_LABELS[level]} className={cn('inline-flex items-center text-chili', className)}>
      {Array.from({ length: level }, (_, index) => (
        <Flame key={index} aria-hidden className="size-3.5 fill-current" />
      ))}
      <span className="sr-only">{label}</span>
    </span>
  )
}

/** Three-step meter used in the dish sheet and the spice guide. */
export function SpiceMeter({ level, className }: { level: SpiceLevel; className?: string }) {
  return (
    <span aria-hidden className={cn('inline-flex items-center gap-0.5', className)}>
      {[1, 2, 3].map((step) => (
        <Flame
          key={step}
          className={cn(
            'size-[1.125rem]',
            step <= level ? 'fill-current text-chili' : 'text-muted-foreground/35',
          )}
        />
      ))}
    </span>
  )
}

export function DietaryTags({ tags, className }: { tags: DietaryTag[]; className?: string }) {
  const visible = displayDietaryTags(tags)
  if (visible.length === 0) return null

  return (
    <span className={cn('inline-flex items-center gap-1', className)}>
      {visible.map((tag) => (
        <Badge
          key={tag}
          variant="outline"
          title={DIETARY_INFO[tag].label}
          className="h-5 rounded-md px-1.5 text-[0.6875rem] font-semibold tracking-wide text-muted-foreground"
        >
          <span aria-hidden>{DIETARY_INFO[tag].short}</span>
          <span className="sr-only">{DIETARY_INFO[tag].label}</span>
        </Badge>
      ))}
    </span>
  )
}

export function DietaryChips({ tags }: { tags: DietaryTag[] }) {
  const visible = displayDietaryTags(tags)

  if (visible.length === 0) {
    return <span className="text-sm text-muted-foreground">Contains meat or seafood</span>
  }

  return (
    <span className="flex flex-wrap gap-2">
      {visible.map((tag) => {
        const Icon = DIETARY_ICONS[tag]
        return (
          <Badge key={tag} variant="outline" className="h-7 gap-1.5 px-2.5 text-xs text-foreground">
            <Icon data-icon="inline-start" aria-hidden className="text-primary" />
            {DIETARY_INFO[tag].label}
          </Badge>
        )
      })}
    </span>
  )
}

export function DishBadgeLabel({ badge, className }: { badge: DishBadge; className?: string }) {
  const Icon = badge === 'chef' ? ChefHat : Star

  return (
    <Badge
      variant="outline"
      className={cn(
        'h-6 gap-1 border-primary/35 bg-primary/10 px-2.5 text-xs font-semibold text-primary',
        className,
      )}
    >
      <Icon
        data-icon="inline-start"
        aria-hidden
        className={badge === 'popular' ? 'fill-current' : undefined}
      />
      {BADGE_LABELS[badge]}
    </Badge>
  )
}
