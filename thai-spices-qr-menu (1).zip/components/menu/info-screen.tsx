'use client'

import { useEffect, useId, useRef, useState, type ReactNode } from 'react'
import Image from 'next/image'
import {
  Check,
  ChevronRight,
  Clock,
  Copy,
  MapPin,
  Phone,
  Wifi,
  type LucideIcon,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  DIETARY_INFO,
  DIETARY_TAGS,
  SPICE_HINTS,
  SPICE_LABELS,
  SPICE_LEVELS,
} from '@/lib/menu-data'
import { restaurant } from '@/lib/restaurant'
import { cn } from '@/lib/utils'
import { DIETARY_ICONS, SpiceMeter } from './dish-meta'

export function InfoScreen() {
  return (
    <div className="animate-in fade-in-0 slide-in-from-bottom-2 px-5 pt-5 duration-300 ease-out">
      <section className="relative overflow-hidden rounded-3xl border border-border bg-card">
        <div className="relative aspect-[16/10] w-full">
          <Image
            src="/images/dining-room.webp"
            alt={restaurant.diningRoomAlt}
            fill
            sizes="(min-width: 768px) 45rem, 100vw"
            className="object-cover"
          />
          <div aria-hidden className="absolute inset-0 bg-linear-to-t from-card via-card/35 to-transparent" />
        </div>
        <div className="absolute inset-x-0 bottom-0 p-5">
          <h1 className="font-serif text-[2.25rem] leading-none text-foreground">
            Thai <span className="text-primary italic">Spices</span>
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground">{restaurant.tagline}</p>
        </div>
      </section>

      <div className="mt-4 flex flex-col gap-3">
        <InfoCard>
          <div className="divide-y divide-border">
            <InfoRow
              icon={Clock}
              label="Opening hours"
              value={restaurant.hours}
              hint={restaurant.lastOrder}
            />
            <InfoRow
              icon={MapPin}
              label="Address"
              value={restaurant.address}
              href={restaurant.mapsUrl}
              actionLabel="Open in Maps"
              external
            />
            <InfoRow
              icon={Phone}
              label="Reservations"
              value={restaurant.phoneDisplay}
              href={restaurant.phoneHref}
              actionLabel="Call the restaurant"
            />
          </div>
        </InfoCard>

        <WifiCard />

        <InfoCard title="Spice guide" description="Every dish can be made milder or hotter — just ask.">
          <ul className="divide-y divide-border">
            {SPICE_LEVELS.map((level) => (
              <li key={level} className="flex items-center gap-3 px-4 py-3">
                <SpiceMeter level={level} className="w-[3.75rem] shrink-0" />
                <span className="flex min-w-0 flex-col">
                  <span className="text-sm font-medium text-foreground">{SPICE_LABELS[level]}</span>
                  <span className="text-xs text-muted-foreground">{SPICE_HINTS[level]}</span>
                </span>
              </li>
            ))}
          </ul>
        </InfoCard>

        <InfoCard title="Dietary key">
          <ul className="divide-y divide-border">
            {DIETARY_TAGS.map((tag) => {
              const Icon = DIETARY_ICONS[tag]
              return (
                <li key={tag} className="flex items-center gap-3 px-4 py-3">
                  <Badge
                    variant="outline"
                    className="h-6 min-w-9 justify-center rounded-md text-[0.6875rem] font-semibold tracking-wide text-muted-foreground"
                  >
                    {DIETARY_INFO[tag].short}
                  </Badge>
                  <Icon aria-hidden className="size-4 shrink-0 text-primary" />
                  <span className="flex min-w-0 flex-col">
                    <span className="text-sm font-medium text-foreground">{DIETARY_INFO[tag].label}</span>
                    <span className="text-xs text-muted-foreground">{DIETARY_INFO[tag].hint}</span>
                  </span>
                </li>
              )
            })}
          </ul>
        </InfoCard>

        <p className="px-1 text-xs leading-relaxed text-muted-foreground">
          {restaurant.allergyNote}
        </p>
      </div>
    </div>
  )
}

function InfoCard({
  title,
  description,
  children,
}: {
  title?: string
  description?: string
  children: ReactNode
}) {
  return (
    <section className="overflow-hidden rounded-2xl border border-border bg-card">
      {title ? (
        <header className="px-4 pt-4 pb-2">
          <h2 className="font-serif text-[1.375rem] leading-tight text-foreground">{title}</h2>
          {description ? <p className="mt-0.5 text-xs text-muted-foreground">{description}</p> : null}
        </header>
      ) : null}
      {children}
    </section>
  )
}

function InfoRow({
  icon: Icon,
  label,
  value,
  hint,
  href,
  actionLabel,
  external = false,
}: {
  icon: LucideIcon
  label: string
  value: string
  hint?: string
  href?: string
  actionLabel?: string
  external?: boolean
}) {
  const content = (
    <>
      <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-secondary text-primary">
        <Icon aria-hidden className="size-[1.125rem]" />
      </span>
      <span className="flex min-w-0 flex-1 flex-col">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-sm font-medium text-foreground">{value}</span>
        {hint ? <span className="text-xs text-muted-foreground">{hint}</span> : null}
      </span>
      {href ? <ChevronRight aria-hidden className="size-4 shrink-0 text-muted-foreground" /> : null}
    </>
  )
  const rowClassName = 'flex items-center gap-3 px-4 py-3.5'

  if (!href) return <div className={rowClassName}>{content}</div>

  return (
    <a
      href={href}
      target={external ? '_blank' : undefined}
      rel={external ? 'noopener noreferrer' : undefined}
      aria-label={actionLabel ? `${actionLabel}: ${value}` : undefined}
      className={cn(
        rowClassName,
        'transition-colors duration-150 hover:bg-secondary/60 active:bg-secondary focus-visible:bg-secondary focus-visible:outline-none',
      )}
    >
      {content}
    </a>
  )
}

function WifiCard() {
  const titleId = useId()
  const [copied, setCopied] = useState(false)
  const resetTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    return () => {
      if (resetTimer.current) clearTimeout(resetTimer.current)
    }
  }, [])

  const copyPassword = async () => {
    try {
      await navigator.clipboard.writeText(restaurant.wifi.password)
      setCopied(true)
      if (resetTimer.current) clearTimeout(resetTimer.current)
      resetTimer.current = setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(false)
    }
  }

  return (
    <section
      aria-labelledby={titleId}
      className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4"
    >
      <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-secondary text-primary">
        <Wifi aria-hidden className="size-[1.125rem]" />
      </span>
      <div className="flex min-w-0 flex-1 flex-col">
        <h2 id={titleId} className="text-xs font-normal text-muted-foreground">
          Guest Wi-Fi
        </h2>
        <p className="truncate text-sm font-medium text-foreground">{restaurant.wifi.network}</p>
        <p className="text-xs text-muted-foreground">
          Password:{' '}
          <span className="font-medium tracking-wide text-foreground">{restaurant.wifi.password}</span>
        </p>
      </div>
      <Button
        variant="outline"
        onClick={copyPassword}
        aria-label={copied ? 'Copied' : 'Copy Wi-Fi password'}
        className="h-10 shrink-0 rounded-full bg-card px-3.5"
      >
        {copied ? (
          <Check data-icon="inline-start" aria-hidden className="text-primary" />
        ) : (
          <Copy data-icon="inline-start" aria-hidden />
        )}
        {copied ? 'Copied' : 'Copy'}
      </Button>
      <span role="status" className="sr-only">
        {copied ? 'Copied' : ''}
      </span>
    </section>
  )
}
