'use client'

import { Minus, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'

export function QuantityStepper({
  value,
  onChange,
  min = 1,
  max = 20,
  size = 'default',
  label,
}: {
  value: number
  onChange: (value: number) => void
  min?: number
  max?: number
  size?: 'default' | 'sm'
  label?: string
}) {
  const isSmall = size === 'sm'
  const buttonClass =
    'grid aspect-square h-full place-items-center rounded-full text-foreground transition-[transform,background-color] duration-150 hover:bg-accent active:scale-90 active:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-30'

  return (
    <div
      role="group"
      aria-label={label ? `Quantity: ${label}` : 'Quantity'}
      className={cn(
        'flex shrink-0 items-center rounded-full border border-border bg-secondary',
        isSmall ? 'h-10' : 'h-12',
      )}
    >
      <button
        type="button"
        aria-label="Decrease quantity"
        disabled={value <= min}
        onClick={() => onChange(Math.max(min, value - 1))}
        className={buttonClass}
      >
        <Minus aria-hidden className={isSmall ? 'size-3.5' : 'size-4'} />
      </button>
      <span
        aria-live="polite"
        className={cn(
          'text-center font-semibold text-foreground tabular-nums',
          isSmall ? 'min-w-6 text-sm' : 'min-w-8 text-base',
        )}
      >
        {value}
      </span>
      <button
        type="button"
        aria-label="Increase quantity"
        disabled={value >= max}
        onClick={() => onChange(Math.min(max, value + 1))}
        className={buttonClass}
      >
        <Plus aria-hidden className={isSmall ? 'size-3.5' : 'size-4'} />
      </button>
    </div>
  )
}
