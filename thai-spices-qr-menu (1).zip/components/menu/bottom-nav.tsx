'use client'

import { BookOpen, Heart, Info, Search, type LucideIcon } from 'lucide-react'
import { useFavorites } from '@/hooks/use-favorites'
import { cn } from '@/lib/utils'
import { useAppState, type AppTab } from './app-state'

const NAV_ITEMS: { id: AppTab; label: string; icon: LucideIcon }[] = [
  { id: 'menu', label: 'Menu', icon: BookOpen },
  { id: 'search', label: 'Search', icon: Search },
  { id: 'favorites', label: 'Favorites', icon: Heart },
  { id: 'info', label: 'Info', icon: Info },
]

export function BottomNav() {
  const { activeTab, navigate } = useAppState()
  const { favorites } = useFavorites()

  return (
    <nav aria-label="Main" className="fixed inset-x-0 bottom-0 z-40">
      <ul className="mx-auto grid h-(--nav-height) max-w-md grid-cols-4 border-t border-border bg-background/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:max-w-3xl md:border-x">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => {
          const isActive = activeTab === id
          const badge = id === 'favorites' && favorites.length > 0 ? favorites.length : null

          return (
            <li key={id} className="flex">
              <button
                type="button"
                onClick={() => navigate(id)}
                aria-current={isActive ? 'page' : undefined}
                className={cn(
                  'group flex flex-1 flex-col items-center justify-center gap-1 text-xs font-medium transition-colors duration-200 focus-visible:outline-none',
                  isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                <span
                  className={cn(
                    'relative flex h-8 w-14 items-center justify-center rounded-full transition-[background-color,transform] duration-300 ease-out group-active:scale-90 group-focus-visible:ring-2 group-focus-visible:ring-ring',
                    isActive ? 'bg-primary/15' : 'group-active:bg-secondary',
                  )}
                >
                  <Icon
                    aria-hidden
                    strokeWidth={isActive ? 2.25 : 1.75}
                    className={cn('size-5', isActive && id === 'favorites' && 'fill-current')}
                  />
                  {badge !== null ? (
                    <span
                      key={badge}
                      aria-hidden
                      className="absolute -top-0.5 right-2 flex h-4 min-w-4 animate-bump items-center justify-center rounded-full bg-primary px-1 text-[0.625rem] leading-none font-semibold text-primary-foreground tabular-nums ring-2 ring-background"
                    >
                      {badge}
                    </span>
                  ) : null}
                </span>
                <span>
                  {label}
                  {badge !== null ? <span className="sr-only"> ({badge})</span> : null}
                </span>
              </button>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
