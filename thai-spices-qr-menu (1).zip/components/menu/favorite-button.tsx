'use client'

import { useState } from 'react'
import { Heart } from 'lucide-react'
import { useFavorites } from '@/hooks/use-favorites'
import { haptic } from '@/lib/haptics'
import { cn } from '@/lib/utils'

export function FavoriteButton({
  dishId,
  name,
  variant = 'plain',
  className,
}: {
  dishId: string
  name: string
  variant?: 'plain' | 'overlay'
  className?: string
}) {
  const { isFavorite, toggleFavorite } = useFavorites()
  const [isPopping, setIsPopping] = useState(false)
  const active = isFavorite(dishId)

  const handleClick = () => {
    if (!active) {
      setIsPopping(true)
      haptic()
    }
    toggleFavorite(dishId)
  }

  return (
    <button
      type="button"
      aria-pressed={active}
      aria-label={`Favorite ${name}`}
      onClick={handleClick}
      className={cn(
        'z-10 grid size-10 shrink-0 place-items-center rounded-full transition-[color,background-color,transform] duration-200 active:scale-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
        variant === 'overlay'
          ? 'bg-background/65 text-foreground backdrop-blur-md hover:bg-background/80'
          : 'text-muted-foreground hover:bg-secondary hover:text-foreground',
        active && 'text-primary hover:text-primary',
        className,
      )}
    >
      <Heart
        aria-hidden
        onAnimationEnd={() => setIsPopping(false)}
        className={cn('size-5', active && 'fill-current', isPopping && 'animate-heart-pop')}
      />
    </button>
  )
}
