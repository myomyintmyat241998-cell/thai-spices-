'use client'

import { Activity } from 'react'
import { AppHeader } from './app-header'
import { AppProviders, useAppState } from './app-state'
import { BottomNav } from './bottom-nav'
import { DishSheet } from './dish-sheet'
import { FavoritesScreen } from './favorites-screen'
import { InfoScreen } from './info-screen'
import { MenuScreen } from './menu-screen'
import { OrderBar } from './order-bar'
import { SearchScreen } from './search-screen'
import type { MenuSnapshot } from '@/lib/menu-data'

export function MenuApp({ table, initialData }: { table: string; initialData?: MenuSnapshot }) {
  return (
    <AppProviders table={table} initialData={initialData}>
      <AppShell />
    </AppProviders>
  )
}

function AppShell() {
  const { activeTab } = useAppState()

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col md:max-w-3xl md:border-x md:border-border">
      <AppHeader />
      <main className="flex-1 pb-[calc(var(--nav-height)+2.5rem)]">
        <Activity mode={activeTab === 'menu' ? 'visible' : 'hidden'}>
          <MenuScreen />
        </Activity>
        <Activity mode={activeTab === 'search' ? 'visible' : 'hidden'}>
          <SearchScreen />
        </Activity>
        <Activity mode={activeTab === 'favorites' ? 'visible' : 'hidden'}>
          <FavoritesScreen />
        </Activity>
        <Activity mode={activeTab === 'info' ? 'visible' : 'hidden'}>
          <InfoScreen />
        </Activity>
      </main>
      <OrderBar />
      <BottomNav />
      <DishSheet />
    </div>
  )
}
