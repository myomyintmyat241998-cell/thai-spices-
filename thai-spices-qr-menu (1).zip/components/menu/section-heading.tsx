import { cn } from '@/lib/utils'

export function SectionHeading({
  id,
  title,
  meta,
  description,
  className,
}: {
  id?: string
  title: string
  meta?: string
  description?: string
  className?: string
}) {
  return (
    <div className={cn('flex flex-col gap-1', className)}>
      <div className="flex items-baseline justify-between gap-4">
        <h2 id={id} className="font-serif text-[1.625rem] leading-tight text-foreground">
          {title}
        </h2>
        {meta ? (
          <span className="shrink-0 text-xs font-medium text-muted-foreground tabular-nums">{meta}</span>
        ) : null}
      </div>
      {description ? <p className="text-sm text-pretty text-muted-foreground">{description}</p> : null}
    </div>
  )
}
