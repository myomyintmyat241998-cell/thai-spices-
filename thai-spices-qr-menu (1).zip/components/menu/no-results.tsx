'use client'

import { SearchX } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@/components/ui/empty'
import { SEARCH_SUGGESTIONS } from '@/lib/search'
import { cn } from '@/lib/utils'
import { useAppState } from './app-state'

export function NoResults({
  query,
  onClear,
  className,
}: {
  query: string
  onClear: () => void
  className?: string
}) {
  const { setQuery } = useAppState()

  return (
    <Empty
      className={cn(
        'animate-in fade-in-0 zoom-in-95 rounded-3xl border border-dashed border-border bg-card/40 px-6 py-10 duration-300',
        className,
      )}
    >
      <EmptyHeader>
        <EmptyMedia
          variant="icon"
          className="size-14 rounded-full bg-primary/12 text-primary [&_svg:not([class*='size-'])]:size-6"
        >
          <SearchX />
        </EmptyMedia>
        <EmptyTitle className="font-serif text-2xl font-normal tracking-normal text-foreground">
          No dishes found
        </EmptyTitle>
        <EmptyDescription>
          {query
            ? `Nothing matches “${query}”. Try a dish name or an ingredient like prawn or basil.`
            : 'No dishes match these filters. Try removing one.'}
        </EmptyDescription>
      </EmptyHeader>
      <EmptyContent className="gap-4">
        <Button variant="outline" onClick={onClear} className="h-11 rounded-full px-5">
          Clear all
        </Button>
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs text-muted-foreground">Try searching for</span>
          <div className="flex flex-wrap justify-center gap-2">
            {SEARCH_SUGGESTIONS.slice(0, 3).map((suggestion) => (
              <Button
                key={suggestion}
                variant="secondary"
                onClick={() => setQuery(suggestion)}
                className="h-10 rounded-full px-4"
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      </EmptyContent>
    </Empty>
  )
}
